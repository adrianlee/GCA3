GCA3
====

GCA3


move joystick into joystick.js

sprite image