var levelJSON = [];

var sample = {
    enemy: [
        {
            type: 0,
            amount: 1,
            interporlation: 0
        },
        {
            type: 1,
            amount: 1,
            interpolation: 0
        },
        {
            type: 2,
            amount: 1,
            interpolation: 0
        },
        {
            type: 3,
            amount: 1,
            interpolation: 0
        },
        {
            type: 4,
            amount: 1,
            interpolation: 0
        }
    ],
    background: 'tile',
    music: 'main',
    powerup: 5
};

var sample2 = {
    enemy: [
        {
            type: 0,
            amount: 5,
            interporlation: 0
        },
        {
            type: 1,
            amount: 1,
            interpolation: 0
        }
    ]
};

levelJSON.push(sample);
levelJSON.push(sample2);